package com.cg.springmvc.repo;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import com.cg.springmvc.bean.Customer;
@Repository("repo")
public class CustomerRepositoryImpl implements ICustomerRepository{

	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}

	@Override
	public ArrayList<Customer> getCustomerList() {
		String selAllQuery="SELECT cust FROM Customer cust";
		TypedQuery<Customer> tq=entityManager.createQuery(selAllQuery,Customer.class);
		ArrayList<Customer> bookList=(ArrayList) tq.getResultList();
		return bookList;
	}

}
