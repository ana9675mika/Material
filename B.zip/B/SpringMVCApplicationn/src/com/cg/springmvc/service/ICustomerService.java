package com.cg.springmvc.service;

import java.util.ArrayList;
import com.cg.springmvc.bean.Customer;

public interface ICustomerService {

	public Customer addCustomer(Customer customer);
	public ArrayList<Customer> fetchAllcust();
}
