package AmazonSearch;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	WebDriver driver;
	@Given("^User is on Amazon Page$")
	public void user_is_on_Amazon_Page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("https://www.amazon.in");
	}

	@When("^Enter the product details and clicks the search button$")
	public void enter_the_product_details_and_clicks_the_search_button() throws Throwable {
	    driver.findElement(By.id("twotabsearchtextbox")).sendKeys("soap");
	  
	    driver.findElement(By.className("nav-input")).click();
	    Thread.sleep(500);
	    
	    //driver.navigate().to("https://www.amazon.in/s?k=soap&ref=nb_sb_noss_2");
	    //Thread.sleep(500);
	    
	    driver.findElement(By.linkText("Santoor Sandal And Almond Milk Soap, 125g (Pack Of 5)")).click();
	    }

	@Then("^navigate to the product details page$")
	public void navigate_to_the_product_details_page() throws Throwable {
	   driver.findElement(By.id("add-to-cart-button")).click();
	   Thread.sleep(1000);
	   driver.close();
	}

}
