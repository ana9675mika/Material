package com.cg.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WorkingWithForms {
	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/BDD/WorkingWithForms.html");
		
		//Find Username textbox and enter value
		driver.findElement(By.id("txtUserName")).sendKeys("Ana123");
		Thread.sleep(500);
		
		//Find password textbox and enter value
		driver.findElement(By.name("txtPwd")).sendKeys("igate");
		Thread.sleep(500);
		
		//Find Confirm password textbox and enter value
		driver.findElement(By.className("Format")).sendKeys("igate");
		Thread.sleep(500);
		
		
		//Find FirstName textbox and enter value
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Anamika");
		Thread.sleep(500);
		
		//Find 	LastName textbox and enter value
		driver.findElement(By.name("txtLN")).sendKeys("Sengar");
		Thread.sleep(500);
		
		//Find Gender radio button and enter value
		driver.findElement(By.xpath(".//*[@id='rbFemale']")).click();
		Thread.sleep(500);
		
		//Find Date of birth textbox and enter value
		driver.findElement(By.name("DtOB")).sendKeys("05/25/1998");
		Thread.sleep(500);
		
		//Find email textbox and enter value
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		Thread.sleep(500);
	
		//Find Address textbox and enter value
		driver.findElement(By.name("Address")).sendKeys("Hathras");
		Thread.sleep(500);
		

		Select dropCity=new Select(driver.findElement(By.name("City")));
		//dropCity.selectByVisibleText("Mumbai");
		dropCity.selectByIndex(0);
		//dropCity.selectByIndex(2);
		
		//Find Phone textbox and enter value
		//driver.findElement(By.xPath(".//*[@id='txtPhone']")).sendKeys("9675308141");
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9675308141");
		driver.findElement(By.cssSelector("input[value='Music']")).click();
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		//List<WebElement> element=driver.findElements(By.name("chkHobbies"));
		/*for(WebElement val:element)
		 {
		  val.click();
		   try{
			   	Thread.sleep(500);
		   }
		   catch(InterruptedException ex)
		   {
			   System.out.println("not valid");
		   }
		 */
		//Find reset and click on it
		//driver.findElement(By.id("myStyle")).click();
		
		//Find submit and click on it
		driver.findElement(By.name("submit")).click();
		
	}

}
