package HotelBookingAlert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingAlert {
	  static WebDriver driver;
	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/BDD/hotelbooking.html");
		Thread.sleep(500);
		
		//************First Name is Blank**************
		driver.findElement(By.name("txtFN")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		//************First Name is Filled**************
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		
		//************Last Name is Blank**************
		driver.findElement(By.name("txtLN")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		//************Last Name is filled**************
		driver.findElement(By.name("txtLN")).sendKeys("Sengar");
		
		//************Email is Blank**************
		driver.findElement(By.id("txtEmail")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		//************Email is filled**************
		driver.findElement(By.id("txtEmail")).sendKeys("anamika@gmail.com");
		
		//************phone no is Blank**************
		driver.findElement(By.name("Phone")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		//************phone no is Invalid**************
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7896");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
				
		
		//************phone no is valid**************
		driver.findElement(By.name("Phone")).sendKeys("9675308141");
		
		//************Address is Blank**************
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
				
		//************Address is filled**************
		driver.findElement(By.xpath("html/body/div/div/form/table/tbody/tr[6]/td[2]/textarea")).sendKeys("Hathras");
				
		//************City is Blank**************
		Select drpCity=new Select(driver.findElement(By.name("city")));
		drpCity.selectByVisibleText("Select City");
		driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		//***********For Selecting City*****************
		drpCity.selectByVisibleText("Pune");
		
		//***********For Blank State*****************
	    Select drpState=new Select(driver.findElement(By.name("state")));
	    drpState.selectByVisibleText("Select State");
	    driver.findElement(By.id("btnPayment")).click();
		callAlert();
		
		//***********For Selecting State*****************
		drpState.selectByVisibleText("Maharashtra");
		
		//***********For Select No. of Guest Staying*****************
	    Select drpRoom=new Select(driver.findElement(By.name("persons")));
	    drpRoom.selectByVisibleText("3");
	    
	  //************CardHolderName is Blank**************
	  driver.findElement(By.id("txtCardholderName")).sendKeys("");
	  driver.findElement(By.id("btnPayment")).click();
	  callAlert();
	  		
	  //************CardHolderName is filled**************
	  driver.findElement(By.id("txtCardholderName")).sendKeys("Anamika");
	 
	  //************DebitCardNumber is Blank**************
	  driver.findElement(By.id("txtDebit")).sendKeys("");
	  driver.findElement(By.id("btnPayment")).click();
	  callAlert();
	  		
	  //************DebitCardNumber is filled**************
	  driver.findElement(By.id("txtDebit")).sendKeys("3421 1234 0097");
	  
	  //************CVV is Blank**************
	  driver.findElement(By.id("txtCvv")).sendKeys("");
	  driver.findElement(By.id("btnPayment")).click();
	  callAlert();
	  		
	  //************CVV is filled**************
	  driver.findElement(By.id("txtCvv")).sendKeys("342");
	  
	  //************Expiration Month is Blank**************
	  driver.findElement(By.id("txtMonth")).sendKeys("");
	  driver.findElement(By.id("btnPayment")).click();
	  callAlert();
	  		
	  //************Expiration Month is filled**************
	  driver.findElement(By.id("txtMonth")).sendKeys("12");
	  
	  //************Expiration Year is Blank**************
	  driver.findElement(By.id("txtYear")).sendKeys("");
	  driver.findElement(By.id("btnPayment")).click();
	  callAlert();
	  		
	  //************Expiration Year is filled**************
	  driver.findElement(By.id("txtYear")).sendKeys("2024");
	 // driver.findElement(By.id("btnPayment")).click();
	  //callAlert();
	  	
	}
		
		public static void callAlert() throws InterruptedException
		{
			
			String alertMessage=driver.switchTo().alert().getText();
			System.out.println(alertMessage);
			Thread.sleep(500);
			driver.switchTo().alert().accept();
			Thread.sleep(500);
			
		}

	}
