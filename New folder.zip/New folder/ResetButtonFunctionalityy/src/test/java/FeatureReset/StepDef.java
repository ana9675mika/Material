package FeatureReset;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {
	
	WebDriver driver;
	@Given("^Open the firefox and launch the application$")
	public void open_the_firefox_and_launch_the_application() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/BDD/WorkingWithForms.html");
		
	
	}

	@When("^Enter the credentials")
	public void enter_the_Username_and_Password() throws Throwable {
		driver.findElement(By.id("txtUserName")).sendKeys("Ana123");
		Thread.sleep(500);
		driver.findElement(By.name("txtPwd")).sendKeys("igate");
		Thread.sleep(500);
		driver.findElement(By.className("Format")).sendKeys("igate");
		Thread.sleep(500);
		driver.findElement(By.cssSelector("input.Format1")).sendKeys("Anamika");
		Thread.sleep(500);
		driver.findElement(By.name("txtLN")).sendKeys("Sengar");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='rbFemale']")).click();
		Thread.sleep(500);
		driver.findElement(By.name("DtOB")).sendKeys("05/25/1998");
		Thread.sleep(500);
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		Thread.sleep(500);
		driver.findElement(By.name("Address")).sendKeys("Hathras");
		Thread.sleep(500);
		Select dropCity=new Select(driver.findElement(By.name("City")));
		//dropCity.selectByVisibleText("Mumbai");
		dropCity.selectByIndex(0);
		driver.findElement(By.xpath(".//*[@id='txtPhone']")).sendKeys("9675308141");
		driver.findElement(By.cssSelector("input[value='Music']")).click();
		driver.findElement(By.cssSelector("input[value='Reading']")).click();
		
	    
	}

	@Then("^Reset the credential$")
	public void reset_the_credential() throws Throwable {
		driver.findElement(By.id("myStyle")).click();
	    
	}


}
