package AlertPopups;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertBoxDemos {
	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/BDD/WorkingWithForms.html");
		Thread.sleep(500);
		
		//ALERT BOX
		driver.findElement(By.id("alert")).click();
		Thread.sleep(500);
		Alert alert=driver.switchTo().alert();
		System.out.println("The alert message is:"+alert.getText());
		alert.accept();//ok pe click krega
		Thread.sleep(500);
		
		//CONFIRM BOX
		driver.findElement(By.id("confirm")).click();
		Thread.sleep(500);
		Alert confirm=driver.switchTo().alert();
		System.out.println("The confirm message is:"+alert.getText());
		confirm.accept();
		Thread.sleep(500);
		
		//DISMISS THE CONFIRM BOX
		confirm=driver.switchTo().alert();
		System.out.println("The confirm  dismiss message is:"+alert.getText());
		confirm.dismiss();
		Thread.sleep(500);
		
		//PROMPT BOX
		driver.findElement(By.id("prompt")).click();
		Thread.sleep(500);
		Alert prompt=driver.switchTo().alert();
		System.out.println("The prompt message is:"+alert.getText());
		String text=prompt.getText();
		System.out.println(text);
		prompt.sendKeys("Anamika");
		Thread.sleep(500);
		prompt.accept();
		Thread.sleep(500);
		
		//DISMISS THE PROMPT BOX
		driver.findElement(By.id("prompt")).click();
		Thread.sleep(500);
		prompt=driver.switchTo().alert();
		prompt.dismiss();
		
		Thread.sleep(500);
		driver.quit();
	}

}
