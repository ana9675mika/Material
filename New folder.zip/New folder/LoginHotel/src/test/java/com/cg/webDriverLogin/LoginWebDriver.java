package com.cg.webDriverLogin;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginWebDriver {

	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/BDD/login.html");
		
		//check title
		String title=driver.getTitle();
		if(title.contentEquals("Login Page")) System.out.println("********Title Matched**********");
		else System.out.println("********Title NOT Matched**********");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		Thread.sleep(500);
		driver.navigate().refresh();
		
		//Failure in Login on leaving the  UserName blank
		driver.findElement(By.name("userName")).sendKeys("");Thread.sleep(500);
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(500);
		driver.navigate().refresh();
		
		//Failure in Login on leaving the password blank
		driver.findElement(By.name("userName")).sendKeys("capgemini");Thread.sleep(500);
		driver.findElement(By.name("userPwd")).sendKeys("");Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		Thread.sleep(500);
		driver.navigate().refresh();
		
		//Failure in Login on entering both the credentials wrong
		driver.findElement(By.name("userName")).sendKeys("capgemin");Thread.sleep(500);
		driver.findElement(By.name("userPwd")).sendKeys("capg123");Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
		driver.navigate().refresh();
		
		//Successful Login with all valid data
		driver.findElement(By.name("userName")).sendKeys("capgemini");Thread.sleep(500);
		driver.findElement(By.name("userPwd")).sendKeys("capg1234");Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[4]/td[2]/input")).click();
		driver.navigate().to("file:///D:/BDD/hotelbooking.html");
	
	
}
}