package com.cg.webDriverHotel;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HotelWebDriver {

	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/BDD/hotelbooking.html");
		
		//check title
		String title=driver.getTitle();
		if(title.contentEquals("Hotel Booking")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		//driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on leaving the first Name empty 
		driver.findElement(By.name("txtFN")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on leaving the last Name blank
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage1 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage1);
		
		driver.navigate().refresh();
		
		//Failure in hotel Booking on incorrect email format
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("a.gmail.com");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage2 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage2);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on leaving the mobile no. blank 
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage3 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage3);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on incorrect mobileNo format
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("785");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage4 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage4);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on not selecting the city
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity=new Select(driver.findElement(By.name("city")));
		//dropCity.selectByValue(null);
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage5 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage5);
		driver.navigate().refresh();
		
		// Failure in hotel Booking on not selecting the state
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity1=new Select(driver.findElement(By.name("city")));
		dropCity1.selectByVisibleText("Pune");
		Select dropState=new Select(driver.findElement(By.name("state")));
		//dropState.selectByVisibleText("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage6 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage6);
		driver.navigate().refresh();
		
		//Validate the number of rooms alloted
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity2=new Select(driver.findElement(By.name("city")));
		dropCity2.selectByVisibleText("Pune");
		Select dropState1=new Select(driver.findElement(By.name("state")));
		dropState1.selectByVisibleText("Maharashtra");
		Select person=new Select(driver.findElement(By.name("persons")));
		person.selectByVisibleText("5");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage7 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage7);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on leaving the CardHolderName blank
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity3=new Select(driver.findElement(By.name("city")));
		dropCity3.selectByVisibleText("Pune");
		Select dropState2=new Select(driver.findElement(By.name("state")));
		dropState2.selectByVisibleText("Maharashtra");
		Select person1=new Select(driver.findElement(By.name("persons")));
		person1.selectByVisibleText("5");
		driver.findElement(By.id("txtCardholderName")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage8 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage8);
		driver.navigate().refresh();
		
		
		//Failure in hotel Booking on leaving the DebitCardNo blank
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity4=new Select(driver.findElement(By.name("city")));
		dropCity4.selectByVisibleText("Pune");
		Select dropState3=new Select(driver.findElement(By.name("state")));
		dropState3.selectByVisibleText("Maharashtra");
		Select person2=new Select(driver.findElement(By.name("persons")));
		person2.selectByVisibleText("5");
		driver.findElement(By.id("txtCardholderName")).sendKeys("Anamika Sengar");
		driver.findElement(By.id("txtDebit")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage9 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage9);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on leaving the cvv blank 
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity5=new Select(driver.findElement(By.name("city")));
		dropCity5.selectByVisibleText("Pune");
		Select dropState4=new Select(driver.findElement(By.name("state")));
		dropState4.selectByVisibleText("Maharashtra");
		Select person3=new Select(driver.findElement(By.name("persons")));
		person3.selectByVisibleText("5");
		driver.findElement(By.id("txtCardholderName")).sendKeys("Anamika Sengar");
		driver.findElement(By.id("txtDebit")).sendKeys("1236 5478 9012 36");
		driver.findElement(By.name("cvv")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage10 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage10);
		driver.navigate().refresh();
		
		//Failure in hotel Booking on leaving the expirationMonth blank 
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity6=new Select(driver.findElement(By.name("city")));
		dropCity6.selectByVisibleText("Pune");
		Select dropState5=new Select(driver.findElement(By.name("state")));
		dropState5.selectByVisibleText("Maharashtra");
		Select person4=new Select(driver.findElement(By.name("persons")));
		person4.selectByVisibleText("5");
		driver.findElement(By.id("txtCardholderName")).sendKeys("Anamika Sengar");
		driver.findElement(By.id("txtDebit")).sendKeys("1236 5478 9012 36");
		driver.findElement(By.name("cvv")).sendKeys("123");
		driver.findElement(By.id("txtMonth")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage11 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage11);
		driver.navigate().refresh();
		
		
		//Failure in hotel Booking on leaving the expirationYr blank 
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity7=new Select(driver.findElement(By.name("city")));
		dropCity7.selectByVisibleText("Pune");
		Select dropState6=new Select(driver.findElement(By.name("state")));
		dropState6.selectByVisibleText("Maharashtra");
		Select person5=new Select(driver.findElement(By.name("persons")));
		person5.selectByVisibleText("5");
		driver.findElement(By.id("txtCardholderName")).sendKeys("Anamika Sengar");
		driver.findElement(By.id("txtDebit")).sendKeys("1236 5478 9012 36");
		driver.findElement(By.name("cvv")).sendKeys("123");
		driver.findElement(By.id("txtMonth")).sendKeys("12");
		driver.findElement(By.id("txtYear")).sendKeys("");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage12 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage12);
		driver.navigate().refresh();
		
		//Successful hotel booking with all valid data
		driver.findElement(By.name("txtFN")).sendKeys("Anamika");
		driver.findElement(By.xpath("//*[@id='txtLastName']")).sendKeys("Sengar");
		driver.findElement(By.name("Email")).sendKeys("anamika@gmail.com");
		driver.findElement(By.cssSelector("input[pattern='[789][0-9]{9}']")).sendKeys("7252090047");
		Select dropCity8=new Select(driver.findElement(By.name("city")));
		dropCity8.selectByVisibleText("Pune");
		Select dropState7=new Select(driver.findElement(By.name("state")));
		dropState7.selectByVisibleText("Maharashtra");
		Select person6=new Select(driver.findElement(By.name("persons")));
		person6.selectByVisibleText("5");
		driver.findElement(By.id("txtCardholderName")).sendKeys("Anamika Sengar");
		driver.findElement(By.id("txtDebit")).sendKeys("1236 5478 9012 36");
		driver.findElement(By.name("cvv")).sendKeys("123");
		driver.findElement(By.id("txtMonth")).sendKeys("12");
		driver.findElement(By.id("txtYear")).sendKeys("2022");
		driver.findElement(By.id("btnPayment")).click();
		String alertMessage13 = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage13);
		
		driver.navigate().to("file:///D:/BDD/success.html");
	

		
		
	}
	
}
