package PageBeanRegistration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class RegistrationPageFactory {

	WebDriver driver;
	
	    //step 1 : identify elements
		@FindBy(name="userid")
		@CacheLookup
		WebElement pfid;
		
		@FindBy(name="submit")
		@CacheLookup
		WebElement pfbutton;
		
		@FindBy(xpath=".//*[@id='pwd']")
		@CacheLookup
		WebElement pfpwd;
		
		//using how class
		@FindBy(how=How.ID, using="usrname")
		@CacheLookup
		WebElement pfname;
		
		@FindBy(how=How.NAME, using="address")
		@CacheLookup
		WebElement pfaddress;
		
		@FindBy(how=How.NAME, using="country")
		@CacheLookup
		WebElement pfcountry;
		
		@FindBy(how=How.NAME, using="zip")
		@CacheLookup
		WebElement pfzip;
		
		@FindBy(how=How.NAME, using="email")
		@CacheLookup
		WebElement pfemail;
		
		@FindBy(how=How.CSS,using="[type='radio'][value='Female']")
		@CacheLookup
		WebElement pfgender;
		
		@FindBy(how=How.CSS,using="[type='checkbox'][value='noen']")
		@CacheLookup
		WebElement pflanguage;
		
		@FindBy(how=How.NAME, using="desc")
		@CacheLookup
		WebElement pfabout;

		//step 2 : Setters
		
		public void setPfid(String sid) {
			pfid.sendKeys(sid);
		}

		public void setPfbutton() {
			pfbutton.click();
		}

		public void setPfpwd(String spwd) {
			pfpwd.sendKeys(spwd);
		}

		public void setPfname(String sname) {
			 pfname.sendKeys(sname);
		}

		public void setPfaddress(String saddress) {
			pfaddress.sendKeys(saddress);
		}

		public void setPfcountry(String scountry) {
			Select drpCountry = new Select(pfcountry);
			drpCountry.selectByVisibleText(scountry);
		}

		public void setPfzip(String szip) {
			pfzip.sendKeys(szip);
		}

		public void setPfemail(String semail) {
			pfemail.sendKeys(semail);
		}

		public void setPfgender() {
		    pfgender.click();;
		}

		public void setPflanguage() {
			pflanguage.click();
		}

		public void setPfabout(String sabout) {
			pfabout.sendKeys(sabout);
		}

		
		//step 2 : Getters
		public WebElement getPfid() {
			return pfid;
		}

		public WebElement getPfbutton() {
			return pfbutton;
		}

		public WebElement getPfpwd() {
			return pfpwd;
		}

		public WebElement getPfname() {
			return pfname;
		}

		public WebElement getPfaddress() {
			return pfaddress;
		}

		public WebElement getPfcountry() {
			return pfcountry;
		}

		public WebElement getPfzip() {
			return pfzip;
		}

		public WebElement getPfemail() {
			return pfemail;
		}

		public WebElement getPfgender() {
			return pfgender;
		}

		public WebElement getPflanguage() {
			return pflanguage;
		}

		public WebElement getPfabout() {
			return pfabout;
		}
		
		
		
		//initiating Elements
		public RegistrationPageFactory(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
}
