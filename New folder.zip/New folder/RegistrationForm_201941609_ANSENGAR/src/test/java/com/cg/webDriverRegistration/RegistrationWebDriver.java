package com.cg.webDriverRegistration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class RegistrationWebDriver {

	public static void main(String args[]) throws InterruptedException
	{
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.get("file:///D:/BDD/WebPages/RegistrationForm.html");
		
		//check the title
		String title=driver.getTitle();
		if(title.contentEquals("Welcome to JobsWorld")) System.out.println("******Title Matched****");
		else System.out.println("******Title NOT Matched******");
		driver.navigate().refresh();
		  
		       //Failure in hotel Booking on leaving the user id empty 
				driver.findElement(By.name("userid")).sendKeys("");
				driver.findElement(By.name("submit")).click();
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage);
				driver.navigate().refresh();
				
				//Failure in hotel Booking on entering wrong password 
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("123");
				driver.findElement(By.name("submit")).click();
				String alertMessage1 = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage1);
				driver.navigate().refresh();
				
				//Failure in hotel Booking on Entering Wrong name 
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("Anamika123");
				driver.findElement(By.name("username")).sendKeys("a6528");
				driver.findElement(By.name("submit")).click();
				String alertMessage2 = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage2);
				driver.navigate().refresh();
				
				//Failure in hotel Booking on leaving the address empty 
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("Anamika123");
				driver.findElement(By.name("username")).sendKeys("Anamika Sengar");
				driver.findElement(By.name("address")).sendKeys("");
				driver.findElement(By.name("submit")).click();
				String alertMessage3 = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage3);
				driver.navigate().refresh();
				
				//Failure in hotel Booking on not selecting country
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("Anamika123");
				driver.findElement(By.name("username")).sendKeys("Anamika Sengar");
				driver.findElement(By.name("address")).sendKeys("Delhi GT Road");
				Select dropCountry=new Select(driver.findElement(By.name("country")));
				driver.findElement(By.name("submit")).click();
				String alertMessage4 = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage4);
				driver.navigate().refresh();
				
				//Failure in hotel Booking on leaving zip code empty
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("Anamika123");
				driver.findElement(By.name("username")).sendKeys("Anamika Sengar");
				driver.findElement(By.name("address")).sendKeys("Delhi GT Road");
				Select dropCountry1=new Select(driver.findElement(By.name("country")));
				dropCountry1.selectByVisibleText("India");
				driver.findElement(By.name("zip")).sendKeys("");
				driver.findElement(By.name("submit")).click();
				String alertMessage5 = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage5);
				driver.navigate().refresh();
				
				//Failure in hotel Booking on leaving email code empty
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("Anamika123");
				driver.findElement(By.name("username")).sendKeys("Anamika Sengar");
				driver.findElement(By.name("address")).sendKeys("Delhi GT Road");
				Select dropCountry2=new Select(driver.findElement(By.name("country")));
				dropCountry2.selectByVisibleText("India");
				driver.findElement(By.name("zip")).sendKeys("560011");
				driver.findElement(By.name("email")).sendKeys("a.gmail.com");
				driver.findElement(By.name("submit")).click();
				String alertMessage6 = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage6);
				driver.navigate().refresh();
				
				//Failure in hotel Booking on not selecting gender
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("Anamika123");
				driver.findElement(By.name("username")).sendKeys("Anamika Sengar");
				driver.findElement(By.name("address")).sendKeys("Delhi GT Road");
				Select dropCountry3=new Select(driver.findElement(By.name("country")));
				dropCountry3.selectByVisibleText("India");
				driver.findElement(By.name("zip")).sendKeys("560011");
				driver.findElement(By.name("email")).sendKeys("anamika@gmail.com");
				
				driver.findElement(By.name("submit")).click();
				String alertMessage7 = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
			    System.out.println("******" + alertMessage7);
				driver.navigate().refresh();
				
				// enters valid data
				driver.findElement(By.name("userid")).sendKeys("Anamika");
				driver.findElement(By.id("pwd")).sendKeys("Anamika123");
				driver.findElement(By.name("username")).sendKeys("Anamika Sengar");
				driver.findElement(By.name("address")).sendKeys("Delhi GT Road");
				Select dropCountry4=new Select(driver.findElement(By.name("country")));
				dropCountry4.selectByVisibleText("India");
				driver.findElement(By.name("zip")).sendKeys("560011");
				driver.findElement(By.name("email")).sendKeys("anamika@gmail.com");
				driver.findElement(By.xpath("html/body/form/ul/li[17]/input")).click();
				driver.findElement(By.xpath("html/body/form/ul/li[20]/input")).click();
				driver.findElement(By.xpath(".//*[@id='desc']")).sendKeys("Anamika Sengar");;
				driver.findElement(By.name("submit")).click();
				driver.close();
				
	
		
		
		
	}
}
