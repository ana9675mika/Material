package RegistrationForm;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBeanRegistration.RegistrationPageFactory;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefRegistration {

	private WebDriver driver;
	private RegistrationPageFactory rpf;
	
	//User is on Registration Form page
	@Given("^User is on Registration Form page$")
	public void user_is_on_Registration_Form_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\BDD\\chromedriver_win32\\ChromeDriver.exe");
		driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		rpf=new RegistrationPageFactory(driver);
		driver.get("file:///D:/BDD/WebPages/RegistrationForm.html");
	}

	//check the title of the page
	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Welcome to JobsWorld")) System.out.println("******Title Matched****");
		else System.out.println("******Title NOT Matched******");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		//driver.close();
	}

	//user leaves User Id Blank or enters wrong user id  and clicks the button
	@When("^user leaves User Id Blank or enters wrong user id  and clicks the button$")
	public void user_leaves_User_Id_Blank_or_enters_wrong_user_id_and_clicks_the_button() throws Throwable {
	  rpf.setPfid(""); Thread.sleep(500);
	  rpf.setPfbutton();
	}

	//display alert msg
	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
	    System.out.println("******" + alertMessage);
	    driver.close();
	}

	//user leaves Password Blank or enters wrong password  and clicks the button
	@When("^user leaves Password Blank or enters wrong password  and clicks the button$")
	public void user_leaves_Password_Blank_or_enters_wrong_password_and_clicks_the_button() throws Throwable {
	    rpf.setPfid("Anamika"); Thread.sleep(500);
		rpf.setPfpwd("123"); Thread.sleep(500);
	    rpf.setPfbutton();
	}

	//user leaves name Blank or user enters wrong name and clicks the button
	@When("^user leaves name Blank or user enters wrong name and clicks the button$")
	public void user_leaves_name_Blank_or_user_enters_wrong_name_and_clicks_the_button() throws Throwable {
		 rpf.setPfid("Anamika"); Thread.sleep(500);
			rpf.setPfpwd("anamika"); Thread.sleep(500);
			rpf.setPfname("a6578"); Thread.sleep(500);
		    rpf.setPfbutton();
	}

	//user enters address not having alphanumeric characters and clicks the button
	@When("^user enters address not having alphanumeric characters and clicks the button$")
	public void user_enters_address_not_having_alphanumeric_characters_and_clicks_the_button() throws Throwable {
		 rpf.setPfid("Anamika"); Thread.sleep(500);
			rpf.setPfpwd("anamika"); Thread.sleep(500);
			rpf.setPfname("Anamika Sengar"); Thread.sleep(500);
			rpf.setPfaddress("Delhi GT*@!Road"); Thread.sleep(500);
		    rpf.setPfbutton();
	}

	//user does not select country and clicks the button
	@When("^user does not select country and clicks the button$")
	public void user_does_not_select_country_and_clicks_the_button() throws Throwable {
		 rpf.setPfid("Anamika"); Thread.sleep(500);
			rpf.setPfpwd("anamika"); Thread.sleep(500);
			rpf.setPfname("Anamika Sengar"); Thread.sleep(500);
			rpf.setPfaddress("Delhi GT Road"); Thread.sleep(500);
			rpf.setPfcountry("(Please select a country)"); Thread.sleep(500);
		    rpf.setPfbutton();
	}

	//user enters wrong zip code and clicks the button
	@When("^user enters wrong zip code and clicks the button$")
	public void user_enters_wrong_zip_code_and_clicks_the_button() throws Throwable {
		rpf.setPfid("Anamika"); Thread.sleep(500);
		rpf.setPfpwd("anamika"); Thread.sleep(500);
		rpf.setPfname("Anamika Sengar"); Thread.sleep(500);
		rpf.setPfaddress("Delhi GT Road"); Thread.sleep(500);
		rpf.setPfcountry("India"); Thread.sleep(500);
		rpf.setPfzip("asgm"); Thread.sleep(500);
	    rpf.setPfbutton();
	}

	//user enters incorrect email and clicks the button
	@When("^user enters incorrect email and clicks the button$")
	public void user_enters_incorrect_email_and_clicks_the_button() throws Throwable {
		rpf.setPfid("Anamika"); Thread.sleep(500);
		rpf.setPfpwd("anamika"); Thread.sleep(500);
		rpf.setPfname("Anamika Sengar"); Thread.sleep(500);
		rpf.setPfaddress("Delhi GT Road"); Thread.sleep(500);
		rpf.setPfcountry("India"); Thread.sleep(500);
		rpf.setPfzip("560011"); Thread.sleep(500);
		rpf.setPfemail("as.gmail.com"); Thread.sleep(500);
	    rpf.setPfbutton();
	}

	//user does not select gender and clicks the button
	@When("^user does not select gender and clicks the button$")
	public void user_does_not_select_gender_and_clicks_the_button() throws Throwable {
		rpf.setPfid("Anamika"); Thread.sleep(500);
		rpf.setPfpwd("anamika"); Thread.sleep(500);
		rpf.setPfname("Anamika Sengar"); Thread.sleep(500);
		rpf.setPfaddress("Delhi GT Road"); Thread.sleep(500);
		rpf.setPfcountry("India"); Thread.sleep(500);
		rpf.setPfzip("560011"); Thread.sleep(500);
		rpf.setPfemail("anamika@gmail.com"); Thread.sleep(500);
		
	    rpf.setPfbutton();
	}

	//user enters all valid data and select language
	@When("^user enters all valid data and select language$")
	public void user_enters_all_valid_data_and_select_language() throws Throwable {
		rpf.setPfid("Anamika"); Thread.sleep(500);
		rpf.setPfpwd("anamika"); Thread.sleep(500);
		rpf.setPfname("Anamika Sengar"); Thread.sleep(500);
		rpf.setPfaddress("Delhi GT Road"); Thread.sleep(500);
		rpf.setPfcountry("India"); Thread.sleep(500);
		rpf.setPfzip("560011"); Thread.sleep(500);
		rpf.setPfemail("anamika@gmail.com"); Thread.sleep(500);
		rpf.setPfgender();Thread.sleep(500);
		rpf.setPflanguage(); Thread.sleep(500);
		rpf.setPfabout("Anamika Sengar"); Thread.sleep(500);
	   
	}

	//click the button
	@Then("^click the button$")
	public void click_the_button() throws Throwable {
	    rpf.setPfbutton();
	    driver.close();
	}

}
