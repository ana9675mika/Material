package com.cg.hr;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/*Life Cycle Methods---------->>>>>>>

*Init(ServletConfig)///parametrised and non parametrised.......always prefer non parametrised.Its for initialization.
*Use of init():---- for initialization...resource allocation are donr here.

//service()///it calls on every request
//use of service():-----controlling and transformation

*destroy()/// it calls while un-deploying the servlet.
*use of destroy():----resource deallocation

//Init():----it is not a life cycle method. and it is for initialization and overriding.



//Eager:----created at the time of starting the server. 
 * consumes memory
 * resources right from beginning
 * normally used for the servlets which are always used by all users.
 * load on startup is alive
 * eg: home,login,mainmenu
 
 
 
 ///Lazy:------created only when first request comes in.
  * normally used for servlets which may be instantiated optionally.
  * eg: ListAllEmps,AddNewEmps.
  
   
   
  * Servlet API:-------
 
*/


@WebServlet(urlPatterns="/MyServlet", loadOnStartup=0)
public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init() throws ServletException {
	
		System.out.println("In Init(ServletConfig)");
	}

	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("IN Destoy()");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("In doGet()");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
