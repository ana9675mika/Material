package com.cg.pp.exception;

public class NotEnoughBalanceException extends Exception 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NotEnoughBalanceException(String error)
	{
		super(error);
	}

}
