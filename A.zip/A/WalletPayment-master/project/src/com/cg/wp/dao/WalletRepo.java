package com.cg.wp.dao;

public class WalletRepo {

}
