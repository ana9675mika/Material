package com.cg.wp.service;

import java.util.HashMap;
import java.util.Map;

import com.cg.wp.bean.Customer;

public interface IWalletService {

	

	public Map createAccount(Customer c);
	
	void showBalance(HashMap<Integer, Customer> h1);
	
}
