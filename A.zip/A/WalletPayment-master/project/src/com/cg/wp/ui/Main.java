package com.cg.wp.ui;
import java.util.Scanner;

import com.cg.wp.bean.Customer;
import com.cg.wp.bean.Wallet;
import com.cg.wp.service.WalletDetail;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc=new Scanner(System.in);
      System.out.println("enter your name");
      String name=sc.next();
      System.out.println("enter your phn");
      Long phn=sc.nextLong();
      System.out.println("enter your amount");
      int wallet=sc.nextInt();
      Customer c=new Customer(name, phn, wallet);
      
	WalletDetail wd=new WalletDetail();
	wd.createAccount(c);
	wd.show();
	wd.showBalance(wd.h1);

	}
}
