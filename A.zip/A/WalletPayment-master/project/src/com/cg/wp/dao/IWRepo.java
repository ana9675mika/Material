package com.cg.wp.dao;

public interface IWRepo {

}
