package com.cg.lab9.bean;

public class Lab9_3 {

}
