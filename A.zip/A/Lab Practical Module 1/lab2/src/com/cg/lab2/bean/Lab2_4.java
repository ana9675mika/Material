package com.cg.lab2.bean;

class Person1
{
	private String FirstName;
	private String LastName;
	private char Gender;
	private long Mobile;
	
	public Person1() {
		super();
	}
	
	public Person1(String firstName, String lastName, char gender, long mobile)
	{
		super();
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
		Mobile = mobile;
	}

	

	public void setFirstName(String FirstName)
	{
		this.FirstName=FirstName; //this reference will hold address of current working address
	
	}
	
	 public String getFirstName()
	 {
		return FirstName; 
		 
	 }
	 
	 public void setLastName(String LastName)
		{
			this.LastName = LastName;
		}
	 
	public String getLastName()
	{
		return LastName;
	}
	
	public void setGender(char Gender) 
	{
		this.Gender = Gender;
	}
	
	public char getGender()
	{
		return Gender;
	} 
	
	public void setMobile(long mobile) {
		this.Mobile = mobile;
	}
	 
	public long getMobile() {
		return Mobile;
	}

}

public class Lab2_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person1 p=new Person1("Divya","Barathi",'F',8259674321L);//constructor is useful in initializing the values in starting

		/*p.setFirstName("Sunil"); //set methods will be helpful in later modifications in values
		p.setLastName("Kumar");
		p.setGender('M');
		*/
		
	System.out.println("FirstName: "+p.getFirstName());//functions provide us the actual values of the address
	System.out.println("LastName: "+p.getLastName());
	System.out.println("Gender: "+p.getGender());
	System.out.println("Mobile: "+p.getMobile());
	
		// System.out.println(p);//this will display the address of object p
	}

}
