package com.cg.lab2.bean;

public class Lab2_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("The number is:"+args[0]);
		
   int a=Integer.parseInt(args[0]);
     if(a>=0)
     {
    	 System.out.println("Positive");
     }
     else
     {
    	 System.out.println("Negative");
    	 		
	}
}

}
