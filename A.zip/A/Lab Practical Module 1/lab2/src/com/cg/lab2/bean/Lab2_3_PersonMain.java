package com.cg.lab2.bean;
 class Person
{
	private String FirstName;
	private String LastName;
	private char Gender;
	
	
	public Person() {
		super();
	}
	
	public Person(String firstName, String lastName, char gender)
	{
		super();
		FirstName = firstName;
		LastName = lastName;
		Gender = gender;
	}

	public void setFirstName(String FirstName)
	{
		this.FirstName=FirstName; //this reference will hold address of current working address
	
	}
	
	 public String getFirstName()
	 {
		return FirstName; 
		 
	 }
	 
	 public void setLastName(String LastName)
		{
			this.LastName = LastName;
		}
	 
	public String getLastName()
	{
		return LastName;
	}
	
	public void setGender(char Gender) 
	{
		this.Gender = Gender;
	}
	
	public char getGender()
	{
		return Gender;
	} 
	 
}

public class Lab2_3_PersonMain {

	public static void main(String[] args) {
		
	Person p=new Person("Divya","Barathi",'F');//constructor is useful in initializing the values in starting

		/*p.setFirstName("Sunil"); //set methods will be helpful in later modifications in values
		p.setLastName("Kumar");
		p.setGender('M');
		*/
		
	System.out.println("FirstName is: "+p.getFirstName());//functions provide us the actual values of the address
	System.out.println("LastName is: "+p.getLastName());
	System.out.println("Gender is: "+p.getGender());
		
		// System.out.println(p);//this will display the address of object p
		
       	}
}
