package com.cg.lab1.bean;

public class student {
	
	private int rollNo;
	private String studName;
	private float studMarks;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      System.out.println("hii"+args[0]);
	}

}
