package com.cg.lab3.bean;
import java.util.*;

public class lab3_7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
    Scanner s= new Scanner(System.in);
    System.out.println("enter the 8 chracter username along with '_job':");
    String str=s.nextLine();
    String start=str.substring(0, str.length()-4);
    String end=str.substring(start.length(),str.length());
    String job="_job";
    if((start.length()>7)&&(end.equals(job)))
    {
    
    	System.out.println("True");
    }
    else
    	System.out.println("False");
    
	}

}
