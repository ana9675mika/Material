package com.cg.lab3.bean;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class lab3_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter two date in dd/MM/yyyy format:");
		
		String input1  = scanner.nextLine();
		LocalDate enteredDate1 = LocalDate.parse(input1,formatter);
		
		String input2  = scanner.nextLine();
		LocalDate enteredDate2 = LocalDate.parse(input2,formatter);
		
		Period dif=Period.between(enteredDate1,enteredDate2);
        System.out.printf("the difference is %d years, %d months, %d days",dif.getYears(),dif.getMonths(),dif.getDays());


            
	}

}
