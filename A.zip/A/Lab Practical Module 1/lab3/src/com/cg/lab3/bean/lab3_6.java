package com.cg.lab3.bean;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class lab3_6 {
	public static void zone(String str)
	{
		ZonedDateTime current= ZonedDateTime.now(ZoneId.of(str));
		System.out.println("current time of your zone is "+current.getHour()+":"+current.getMinute());
        System.out.println("current date of your zone is "+current.getDayOfMonth()+"/"+current.getMonthValue()+"/"+current.getYear());
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner s=new Scanner(System.in);
     System.out.println("enter the zoneid:");
     String str=s.nextLine();
     lab3_6.zone(str);
	}

}
