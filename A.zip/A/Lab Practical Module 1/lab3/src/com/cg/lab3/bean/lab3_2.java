package com.cg.lab3.bean;
import java.util.*;

public class lab3_2 {

	public static boolean positive(String str)
	{
	    for(int i = 0;i<str.length()-1;i++)         
	        if(str.charAt(i) > str.charAt(i+1))
	            return false; 
	    return true;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  Scanner sc=new Scanner(System.in);
  String str=sc.nextLine();
  System.out.println(positive(str));
	}

}
