package com.cg.lab3.bean;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class lab3_5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter product purchase date in dd/MM/yyyy format:");
				String ppdate  = scanner.nextLine();
		LocalDate enteredDate1 = LocalDate.parse(ppdate,formatter);
		
		System.out.print("Enter warantee period month :");
				int waranteemonth  = scanner.nextInt();
		
		System.out.print("Enter warantee period year:");
		int waranteeyear  = scanner.nextInt();
        LocalDate result=null;
        if(waranteemonth>0 && waranteemonth<13)
        {
        result=enteredDate1.plusMonths(waranteemonth);
        		}
        else
        	System.out.println("invalid");
        if(waranteeyear>0)
        {
        	System.out.println("expiry date is:"+result.plusYears(waranteeyear));
        }
        else
        	System.out.println("invalid");
				
		
	}
}
