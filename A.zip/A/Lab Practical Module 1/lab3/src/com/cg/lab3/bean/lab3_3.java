package com.cg.lab3.bean;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class lab3_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scanner = new Scanner(System.in);
		System.out.print("Enter date in dd/MM/yyyy format:");
		String input  = scanner.nextLine();
		LocalDate enteredDate = LocalDate.parse(input,formatter);
             LocalDate today =LocalDate.now();
             Period dif=Period.between(enteredDate,today);
             System.out.printf("the difference is %d years, %d months, %d days",dif.getYears(),dif.getMonths(),dif.getDays());
	
	}

}
