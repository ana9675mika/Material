package com.cg.lab3.bean;
import java.util.*;

public class lab3_8 {
	public static void main(String args[])
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the elements seperated by ',':");
		String str=sc.nextLine();
		String[] arr=str.split(",");
		Arrays.sort(arr);
		if((arr.length)%2==0)
		{
		for(int i=0;i<(arr.length)/2;i++)
		{
			System.out.println((arr[i]).toUpperCase()+" ");
		}
		for(int j=(arr.length/2);j<arr.length;j++)
		{
			System.out.println((arr[j]).toLowerCase()+" ");
		}
	}
		else
			{
			for(int i=0;i<=((arr.length)/2);i++)
			{
				System.out.println((arr[i]).toUpperCase()+" ");
			}
			for(int j=(arr.length/2)+1;j<arr.length;j++)
			{
				System.out.println((arr[j]).toLowerCase()+" ");
			}
		}
	}
	
}