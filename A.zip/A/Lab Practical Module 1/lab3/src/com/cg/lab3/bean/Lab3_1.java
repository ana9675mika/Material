package com.cg.lab3.bean;
import java.util.*;
public class Lab3_1 {
	
	 public static void addstring(String str)
	    {
	    	System.out.println(str + str);
	    }
	 
	    public static void replace(String str)
	    {
	    	char s[]=str.toCharArray();
	    	for(int i=0; i<s.length; i++)
	    	{
	    		if((i%2)!=0)
	    		{
	    			s[i]='#';
	    		}
	    	 System.out.print(s[i]);
	    	}
	    }
	    
	    public static void duplicate(String str)
	    {
	    	 String result = "";
	    	    for (int i = 0; i<str.length(); i++) {
	    	        if(!result.contains(String.valueOf(str.charAt(i)))) {
	    	            result += String.valueOf(str.charAt(i));
	    	        }
	    	    }
	    	    System.out.println(result);
	    	}
	    
	    public static void oddupper(String str)
	    {
	    	char s[]=str.toCharArray();
	    	for(int i=0;i<s.length;i++)
	    	{
	    		if((i%2)!=0)
	    		{
	    			System.out.print(Character.toUpperCase(str.charAt(i)));
	    		}
	    		
	    	}
	   	
	    }
	    	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner sc=new Scanner(System.in);
       String str= sc.nextLine();
       System.out.println("enter your choice from 0,1,2,3");
       int ch=sc.nextInt();
       switch(ch)
       {
       case 0: Lab3_1.addstring(str);
       break;
       case 1: Lab3_1.replace(str);
       break;
       case 2: Lab3_1.duplicate(str);
       break;
       case 3: Lab3_1.oddupper(str);
       break;
       default :
           System.out.println("Invalid input");
       }
    		  
   
    		  
    		  
    		  
	}

}
