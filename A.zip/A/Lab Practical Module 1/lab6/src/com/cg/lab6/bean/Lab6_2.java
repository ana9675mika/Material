package com.cg.lab6.bean;

import java.util.Scanner;

@SuppressWarnings("serial")
class Ageexception extends Exception
{

	Ageexception(String msg)
	{
	super(msg);
	}
}
class Lab6_2{
	public static void main(String args[])
	{
		try {
			System.out.println("enter age:");
            Scanner s=new Scanner(System.in);
            int age=s.nextInt();
            
            if(age<15)
            {
            throw new Ageexception("Age of a person should be above 15.");
            
            }
		}
		catch(Ageexception e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("Exception ");
	}
}
