package com.cg.lab6.bean;
import java.lang.Exception;
import java.util.*;


class Nameexception extends Exception
{

	Nameexception(String msg)
	{
	super(msg);
	}
}
class Lab6_1{
	public static void main(String args[])
	{
		try {
			System.out.println("enter firstname and lastname:");
            Scanner s=new Scanner(System.in);
            String fname=s.nextLine();
            String lname=s.nextLine();
            if((fname.equals(""))&&(lname.equals("")))
            {
            throw new Nameexception("firstname and lastname should not be empty");
            
            }
		}
		catch(Nameexception e)
		{
			System.out.println(e.getMessage());
		}
		System.out.println("Exception ");
	}
}

