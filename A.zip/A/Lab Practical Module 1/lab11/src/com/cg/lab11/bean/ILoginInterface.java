package com.cg.lab11.bean;

public interface ILoginInterface {
	boolean login(String uname, String pass);


}
