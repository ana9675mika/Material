package com.cg.lab11.bean;

@FunctionalInterface
public interface IStringSpace {
	public void space(String c);
	

}