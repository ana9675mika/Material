package com.cg.lab11.bean;

public abstract class LoginOperation implements ILoginInterface {

	public static void main(String[] args) {
		ILoginInterface log = (uname,pass)-> uname.equals(pass)? true:false;
		boolean result = log.login("hai","hai");
		System.out.println(result);
	
}

}