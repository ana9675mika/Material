package com.cg.lab11.bean;

public interface PowInterface {
	public double power(double x,double y);
	

}
