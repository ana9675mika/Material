package com.cg.lab11.bean;

@FunctionalInterface
public interface ILab11_4 {
	public Simple methodDemo();


}