package com.cg.lab11.bean;

public @interface FunctionalInterface {

}
