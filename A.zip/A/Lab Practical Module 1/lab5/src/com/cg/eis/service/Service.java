package com.cg.eis.service;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
public class Service implements EmployeeService {
	
           Employee e;
           public Employee setDetails()
           {
        	   Scanner sc=new Scanner(System.in);
               System.out.println("Enter the employee name:");
               String name=sc.next();
               System.out.println("Enter the employee id:");
               int id=sc.nextInt();
               System.out.println("Enter employee designation:");
               String designation=sc.next();
               System.out.println("Enter employee salary:");
               int salary=sc.nextInt();
               System.out.println("enter insurence:");
               String ischeme=sc.next();
                e=new Employee(id,name,designation,ischeme,salary);
               return e;
           }
           public void iScheme(int salary,String designation,Employee a)
           {
        	   if(designation.equals("System Associate") && (salary>5000 && salary<20000))
        	   a.setIscheme("C");
           else if(designation.equals("Programmer") && (salary>=20000 && salary<40000))
        	   a.setIscheme("B");
           else if(designation.equals("Manager") && (salary>=40000))
        	   a.setIscheme("A");
           else if(designation.equals("Clerk") && (salary<5000))
        	   a.setIscheme("No");
        	  
           }
           public void getDetails()
           {
        	 System.out.println("Salary is: "+e.getSalary());
            System.out.println("Employee name is: "+e.getName());
            System.out.println("Employee id is: "+e.getId());
            System.out.println("Employee designation is: "+e.getDesignation());
            System.out.println("Employee insurance scheme is: "+e.getIscheme());
           }
}
