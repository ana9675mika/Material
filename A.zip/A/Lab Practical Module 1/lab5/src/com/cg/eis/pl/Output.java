package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class Output {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Service s= new Service();
       Employee e=s.setDetails();
       
      s.getDetails();
	}

}
