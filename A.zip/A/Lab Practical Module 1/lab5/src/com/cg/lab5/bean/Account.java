package com.cg.lab5.bean;

public  abstract class Account {
	
	protected static long accnum;
	protected double balance;
	public static person accholder;
	
	// constructor
	public Account(long accnum, double balance, person accholder) {
		super();
		this.accnum = accnum;
		this.balance = balance;
		this.accholder = accholder;
	}


	//getters and setters
	public long getAccnum() {
		return accnum;
	}

	public void setAccnum(long accnum) {
		this.accnum = accnum;
	}
	
	public person getAccholder() {
		return accholder;
	}

	public void setAccholder(person accholder) {
		this.accholder = accholder;
	}

	 public double getBalance() {    // getBalance() method
 		return balance;
 	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	//methods
		
		public void deposit(double b) 
		{
			balance=balance+b;
	 	  }
		
        public abstract void withdraw(double b);
       
       
//toString
		@Override
		public String toString() {
			return "Account [accnum=" + accnum + ", balance=" + balance + ", accholder=" + accholder + "]";
		}
		
}


