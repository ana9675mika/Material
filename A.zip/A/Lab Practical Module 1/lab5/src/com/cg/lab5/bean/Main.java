package com.cg.lab5.bean;
public class Main  {
	
		
	public static void main(String[] args) {

	person p1=new person("smith",21.0f);
    person p2=new person("Kathy",21.0f);
   
  	 p1.setAccnum(101);
  	 p1.setName("smith");
  	 p1.setBalance(2000);
  	p2.setAccnum(102);
 	 p2.setName("kathy");
 	 p2.setBalance(3000);
  	 
  	
   	 p1.deposit(2000);
   	 p2.withdraw(2000);
   	 
   	 System.out.println("updated balance in smith's account is:"+p1.getBalance());
   	 System.out.println("updated balance in kathy's account is:"+p2.getBalance());
   

}
}
