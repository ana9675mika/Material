package com.cg.lab42.bean;

public class SavingAccount extends Account {

	 double minbalance=500;
	 boolean withdraw(double a)
	{
		if((balance-a)>minbalance)
		{
			balance=balance-a;
			return true;
		}
		else
			
		return false;
	}
}
