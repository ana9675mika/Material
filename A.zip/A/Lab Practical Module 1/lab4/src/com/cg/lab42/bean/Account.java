package com.cg.lab42.bean;

public class Account {

	 double balance=1000;
	 
	 boolean withdraw(double a)
	    {
		 return true;
		 }
}
