package com.cg.lab42.bean;

public class CurrentAccount extends Account {

	 double odlimit=5000;
	
     boolean withdraw(double a)
     {
    	if(odlimit>a)
    	{
   	  return true;
   	  }
     else
     {
   	  return false;
     }
     }

}
