package com.cg.lab41.bean;

public class Account {
	
	private long accnum;
	private  double balance;
	person accholder;
	
	// constructor
	public Account(long accnum, double balance, person accholder) {
		super();
		this.accnum = accnum;
		this.balance = balance;
		this.accholder = accholder;
	}

	//getters and setters
	public long getAccnum() {
		return accnum;
	}

	public void setAccnum(long accnum) {
		this.accnum = accnum;
	}
	
	public person getAccholder() {
		return accholder;
	}

	public void setAccholder(person accholder) {
		this.accholder = accholder;
	}

	 public double getBalance() {    // getBalance() method
 		return balance;
 	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	//methods
		
		public void deposit(double b) 
		{
			balance=balance+b;
	 	  }
		
        public void withdraw(double b) 
        {
        	if((balance-b)>500)
			{
        		balance=balance-b;
			}
        	
	     	}
       
//toString
		@Override
		public String toString() {
			return "Account [accnum=" + accnum + ", balance=" + balance + ", accholder=" + accholder + "]";
		}
		
}


