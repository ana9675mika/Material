package com.cg.lab41.bean;

public class main {

	public static void main(String[] args) {
		
		person p1=new person("smith",21.0f);
        person p2=new person("Kathy",21.0f);
        
       
        Account acc1=new Account(101,2000,p1);  
       	 Account acc2=new Account(102,3000,p2);
       	
       	 acc1.deposit(2000);
       	 acc2.withdraw(2000);
       	 
       	 System.out.println("updated balance in smith's account is:"+acc1.getBalance());
       	 System.out.println("updated balance in kathy's account is:"+acc2.getBalance());
       

	}

}
