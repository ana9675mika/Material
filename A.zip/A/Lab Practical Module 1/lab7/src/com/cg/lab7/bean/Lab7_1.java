package com.cg.lab7.bean;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Lab7_1 {

	public static void main(String[] args) {
	
		StringBuilder sb = null;
		Scanner s= new Scanner(System.in);
		ArrayList<String> list=new ArrayList();
		
		int n=s.nextInt();
		System.out.println("enter the elements in array:");
		int arr[]=new int[n];
		for(int i=0;i<n;i++)
		 arr[i]=s.nextInt();

		 
   //  String[] str1=str.split(",");
      
       
	     
		for(int i=0;i<arr.length;i++)
		{
			String str=Integer.toString(arr[i]);
		sb=new StringBuilder(str);  
		sb.reverse(); 
		String a=sb.toString();
		list.add(a);
		}
		Collections.sort(list);
		System.out.println(list);
		
	}
	
}
