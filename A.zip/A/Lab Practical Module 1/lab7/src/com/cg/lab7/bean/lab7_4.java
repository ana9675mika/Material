package com.cg.lab7.bean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class lab7_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
              ArrayList l1=new ArrayList();
              Scanner s=new Scanner(System.in);
               System.out.println("enter the no. of elements");
               int n=s.nextInt();
               int[] arr=new int[n];
               for(int i=0;i<n;i++)
            	   arr[i]=s.nextInt();
               lab7_4 l=new lab7_4();
               l.getSquares(arr);
               Set set= l.getSquares(arr).entrySet(); // Get a set of the entries
               Iterator i= set.iterator(); // Get an iterator
               while(i.hasNext()) { // Display elements
               HashMap.Entry me = (HashMap.Entry)i.next();
               System.out.println(me.getKey() + ": "+ me.getValue());
               }
               
	}
	public HashMap<Integer,Integer> getSquares(int arr[])
	
	{
		HashMap<Integer,Integer> squares=new HashMap();
	
	for(int i=0;i<arr.length;i++)
	{
		squares.put(arr[i],arr[i]*arr[i]);
	}
	return squares;

  }
}
