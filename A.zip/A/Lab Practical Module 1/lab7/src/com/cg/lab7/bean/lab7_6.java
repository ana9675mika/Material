package com.cg.lab7.bean;
import java.util.*;
public abstract class lab7_6 {
	
	
	public static void main(String[] args) {
		
		}
}
