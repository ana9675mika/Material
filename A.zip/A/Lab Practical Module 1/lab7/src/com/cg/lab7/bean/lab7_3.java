package com.cg.lab7.bean;

import java.awt.List;
import java.util.ArrayList;
import java.util.Scanner;

public class lab7_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s= new Scanner(System.in);
		System.out.println("enter the no. of elements" );
		int n=s.nextInt();
		ArrayList<String> list1=new ArrayList();
		ArrayList<String> list2=new ArrayList();
		
		System.out.println("enter the elements in first list");
		for(int i=0;i<n;i++)
		{
			String str1=s.next();
			list1.add(str1);
		}
		
		System.out.println("enter the elements in second list");
		
		for(int i=0;i<n;i++)
		{
			String str2=s.next();
			list2.add(str2);
		}
		lab7_3 m=new lab7_3();
		m.removeElements(list1,list2);
		
	}
	public void removeElements(ArrayList list1,  ArrayList<String> list2)
	{ 
		
			list1.removeAll(list2);
		System.out.println("First list is:"+list1);
		System.out.println("Second list is:"+list2);
		
	}

}
