package com.cg.lab7.bean;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
	import java.util.Iterator;
	import java.util.Scanner;
	import java.util.Set;

	public class lab7_5 {

		public static void main(String[] args) {
			// TODO Auto-generated method stub
	              ArrayList<String> l1=new ArrayList();
	              Scanner s=new Scanner(System.in);
	               System.out.println("enter the no. of elements:");
	               int n=s.nextInt();
	               System.out.println("enter the product names:");
	               for(int i=0;i<n;i++)
	               {
	            	   String str=s.next();
	            	   l1.add(str);
	               }
	             Collections.sort(l1);
	             for(String str:l1)
	             {
	            	 System.out.println(str);
	             }
	               
	               }
	               

	}


