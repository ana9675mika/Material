package com.cg.mobileapp.dao;

public interface Show {

	
	public void ShowPurchaseDetail();
}
