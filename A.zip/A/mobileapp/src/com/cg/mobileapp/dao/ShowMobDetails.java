package com.cg.mobileapp.dao;

import java.util.HashMap;

public class ShowMobDetails implements Show {

	

	@Override
	public void ShowPurchaseDetail() {
		// TODO Auto-generated method stub
		
	}

}
