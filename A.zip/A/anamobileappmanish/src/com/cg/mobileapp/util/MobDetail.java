package com.cg.mobileapp.util;

import java.util.Map;

public interface MobDetail {
	
	public Map AddmobDetails();
	

}
