package com.cg.mobileapp.Exception;

public class MobileException extends Exception {
	public  MobileException(String message)
	{ 
		super(message);
	}
}
