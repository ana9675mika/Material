import java.io.IOException;
import java.sql.*;

import com.cg.ems.util.DButil;

public class TestProcedureDemo {
 public static void main(String args[])
 {
	 try {
		Connection con=DButil.getcon();
		CallableStatement cst=con.prepareCall("call pr1(?,?)");
		cst.setInt(1, 111);
		cst.registerOutParameter(2, Types.NUMERIC);
		ResultSet rs=cst.executeQuery();
		System.out.println("salary is:"+cst.getInt(2));
		System.out.println("...................................");
		boolean bb=cst.execute();
		System.out.println("salary is:"+cst.getInt(2));
	} 
	 catch (SQLException | IOException e) 
	 {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
 }
}
