import java.io.IOException;
import java.sql.*;
import java.util.*;

import com.cg.ems.util.DButil;
public class TestDeleteDemo {
    public static void main(String args[]) 
    {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter empid:");
	int eid=sc.nextInt();
	
    try {
		Connection con=DButil.getcon();
		String deleteQry="DELETE FROM emp1 WHERE emp_id=(?)";
				
		PreparedStatement pst=con.prepareStatement(deleteQry);
		pst.setInt(1,eid);
		int data=pst.executeUpdate();
		System.out.println("Data is Deleted "+data);
	} 
    catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
  }
	
}

