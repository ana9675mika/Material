import java.io.IOException;
import java.sql.*;

import com.cg.ems.util.DButil;
public class TestResultSetMetaDataDemo {
public static void main(String args[])
{
	try {
		Connection con=DButil.getcon();
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("SELECT * FROM emp1");
		ResultSetMetaData rsmd=rs.getMetaData();
		int colCount=rsmd.getColumnCount();
		System.out.println("no.of columns:"+colCount);
		for(int i=1;i<=colCount;i++)
		{
			System.out.println(i+":column name :"
					+rsmd.getColumnName(i)
						+"column type :"
					+rsmd.getColumnTypeName(i));
		}
		
	} catch (SQLException | IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}

