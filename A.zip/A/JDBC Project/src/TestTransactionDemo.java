import java.io.IOException;
import java.sql.*;

import com.cg.ems.util.DButil;

public class TestTransactionDemo {
	 
	public static void main(String[] args) {
		Connection con=null;
			try {
			
			con=DButil.getcon();
			con.setAutoCommit(false);
			String update1="UPDATE emp1 SET emp_name='VaishaliS'"
					+ " WHERE emp_id=111";
			String update2="UPDATE emp1 SET emp_sal=5000 WHERE emp_id=222";
			Statement st=con.createStatement();
			st.addBatch(update1);
			st.addBatch(update2);
			int arr[]=st.executeBatch();
			con.commit();
			System.out.println("updated successfully");
		} 
		
		catch (SQLException | IOException e)
		{
			try {
			// TODO Auto-generated catch block
			con.rollback();
			}
			catch(SQLException e1)
			{
			e1.printStackTrace();
		}
			e.printStackTrace();
	}
	}
}


