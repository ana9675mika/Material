package com.cg.lab1.service;

import java.util.ArrayList;

import com.cg.lab1.bean.Author;
import com.cg.lab1.dao.AuthorDao;
import com.cg.lab1.dao.AuthorDaoImpl;

public class AuthorServiceImpl implements AuthorService{

	AuthorDao authDao;
	public AuthorServiceImpl() {
		
		authDao=new AuthorDaoImpl();
	}
	
	@Override
	public Author addEmp(Author author) {
		
		return authDao.addEmp(author);
	}

	@Override
	public ArrayList<Author> fetchAllEmp() {
		
		return authDao.fetchAllEmp();
	}

	@Override
	public Author deleteEmp(int authorId) {
		
		return authDao.deleteEmp(authorId);
	}

	@Override
	public Author getEmpById(int authorId) {
		
		return authDao.getEmpById(authorId);
	}

	@Override
	public Author updateEmp(int authorId, String firstName, String middleName, String lastName, String phoneNo) {
		
		return authDao.updateEmp(authorId, firstName, middleName, lastName, phoneNo);
	}

}
