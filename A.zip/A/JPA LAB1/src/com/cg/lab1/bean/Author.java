package com.cg.lab1.bean;

import javax.persistence.*;

@Entity
public class Author {
	@Id
	@Column(name="author_id",length=10)
	private int authorId;
	
	@Column(name="author_fName",length=10)
	private String firstName;
	
	@Column(name="author_midName",length=10)
	private String middleName;
	
	@Column(name="author_lName",length=10)
	private String lastName;
	
	@Column(name="author_phnNo",length=10)
	private String phoneNo;

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Author(int authorId, String firstName, String middleName, String lastName, String phoneNo) {
		super();
		this.authorId = authorId;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "authorId=" + authorId +"\n"
	            + "firstName=" + firstName +"\n"
				+ "middleName=" + middleName+"\n"
				+ "lastName=" + lastName + "\n"
				+"phoneNo=" + phoneNo;
	}
	
	
	

}
