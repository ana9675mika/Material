package com.cg.lab1.main;
import java.util.ArrayList;
import java.util.Scanner;
import com.cg.lab1.bean.Author;
import com.cg.lab1.service.AuthorServiceImpl;

public class TestAuthor {
	public static void main(String args[])
	{
		
		AuthorServiceImpl authSer= new AuthorServiceImpl();
		Scanner sc=new Scanner(System.in);
		int option = 0;

		do {

			System.out.println("\n1. Inserting The Data");
			System.out.println("2. Data Fetching on the basis of Author Id");
			System.out.println("3.Display All Records");
			System.out.println("4.Delete a Data based on given Author Id");
			System.out.println("5.Update The Data");
			System.out.println("6.Exit");

			option = sc.nextInt();
			switch (option) {
			case 1:
						System.out.println("Enter author id");
						int id=sc.nextInt();
						System.out.println("Enter first name");
						String fName=sc.next();
						System.out.println("Enter middle name");
						String mName=sc.next();
						System.out.println("Enter last name");
						String lName=sc.next();
						System.out.println("Enter phn no.");
						String phn=sc.next();
		
						System.out.println(".........inserting a record........");
						Author a= new Author();
						a.setAuthorId(id);
						a.setFirstName(fName);
						a.setMiddleName(mName);
						a.setLastName(lName);
						a.setPhoneNo(phn);
						Author a2=authSer.addEmp(a);
						System.out.println(a2 + " is inserted in table");
						break;
			case 2:
				
						System.out.println(".....fetch only one record........");
						System.out.println("Enter Author Id To fetch the corresponding data");
						int aId=sc.nextInt();
						Author aa=authSer.getEmpById(aId);
						System.out.println(aa);
						break;
			case 3:
						System.out.println("......fetch all records.........");
						ArrayList<Author> aList=authSer.fetchAllEmp();
						for(Author tempA:aList)
						{
							System.out.println(tempA.getAuthorId()+"\t"
									+tempA.getFirstName()+"\t"
									+tempA.getMiddleName()+"\t"
									+tempA.getLastName()
									+"\t"+tempA.getPhoneNo());;
						}
						break;
			case 4:
						
						System.out.println("..........delete.......");
						System.out.println("Enter Author Id To delete the corresponding data");
						int aaId=sc.nextInt();
						Author deletedauth=authSer.deleteEmp(aaId);
						System.out.println(deletedauth+" deleted");
						break;
			case 5:			
		
						System.out.println("...........update..........");
						System.out.println("Enter author id to update");
						int aid=sc.nextInt();
						System.out.println("Enter first name to update");
						String afName=sc.next();
						System.out.println("Enter middle name to update");
						String amName=sc.next();
						System.out.println("Enter last name to update");
						String alName=sc.next();
						System.out.println("Enter phn no. to update");
						String aphn=sc.next();
						Author updatedAuth=authSer.updateEmp(aid, afName, amName, alName, aphn);
						System.out.println("updated data for "+updatedAuth.getAuthorId());
			break;
			default:
			case 6:
				System.out.println("Exited...");
				break;
			}

		} while (option != 6);
		sc.close();
	
   }
}
