package com.cg.lab1.dao;
import java.util.ArrayList;
import javax.persistence.*;

import com.cg.lab1.bean.Author;
import com.cg.lab1.util.JPAUtil;

public class AuthorDaoImpl implements AuthorDao {
	
	EntityManager em=null;
	EntityTransaction entityTran=null;
	public AuthorDaoImpl()
	{
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
	}
	
	@Override
	public Author addEmp(Author author) {
		entityTran.begin();
		em.persist(author);
		entityTran.commit();
		return author;
	}
	

	@Override
	public ArrayList<Author> fetchAllEmp() {
		String selAllQuery="SELECT auth FROM Author auth";
		TypedQuery<Author> tq=em.createQuery(selAllQuery,Author.class);
		ArrayList<Author> empList=(ArrayList) tq.getResultList();
		return empList;
	}

	@Override
	public Author deleteEmp(int authorId) {
		Author a1=em.find(Author.class, authorId);
		entityTran.begin();
		em.remove(a1);
		entityTran.commit();
		return a1;
	}

	@Override
	public Author getEmpById(int authorId) {
		Author a2=em.find(Author.class, authorId);
		return a2;
	}

	@Override
	public Author updateEmp(int authorId, String firstName, String middleName, String lastName, String phoneNo) {
		Author a3=em.find(Author.class, authorId);
		a3.setFirstName(firstName);
		a3.setMiddleName(middleName);
		a3.setLastName(lastName);
		a3.setPhoneNo(phoneNo);
		
		entityTran.begin();
		em.merge(a3);
		entityTran.commit();
		return a3;
	}


}
