package com.cg.lab1.dao;

import java.util.ArrayList;

import com.cg.lab1.bean.Author;

public interface AuthorDao {

	public Author addEmp(Author author);
	public ArrayList<Author> fetchAllEmp();
	public Author deleteEmp(int authorId);
	public Author getEmpById(int authorId);
	public Author updateEmp(int authorId,String firstName,String middleName,String lastName,String phoneNo);
	
}
