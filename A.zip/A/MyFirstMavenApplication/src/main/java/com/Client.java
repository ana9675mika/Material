package com;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Client {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("hiii*************");
	}

}
