package com.cg.ab.bean;
import javax.persistence.*;

@Entity
public class Author {

	@Id
	@Column(name="auth_Id",length=10)
	private int authId;
	@Column(name="auth_Name",length=25)
	private String name;
	
	public int getAuthId() {
		return authId;
	}
	public void setAuthId(int authId) {
		this.authId = authId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Author(int authId, String name) {
		super();
		this.authId = authId;
		this.name = name;
	}
	
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "authId=" + authId + ", name=" + name;
	}
	
	
}
