package com.cg.ab.service;

import java.util.ArrayList;

import com.cg.ab.bean.Author;

public interface AuthorServiceInterface {

	public Author addAuth(Author auth);
	public ArrayList<Author> fetchAllEmp();
	public Author deleteEmp(int authId);
	public Author getEmpById(int authId);
	public Author updateEmp(int authId,String name);
	
}
