package com.cg.ab.service;

import java.util.ArrayList;

import com.cg.ab.bean.Author;

public class AuthorServiceImpl implements AuthorServiceInterface {

	@Override
	public Author addAuth(Author auth) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Author> fetchAllEmp() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author deleteEmp(int authId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author getEmpById(int authId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author updateEmp(int authId, String name) {
		// TODO Auto-generated method stub
		return null;
	}


}
