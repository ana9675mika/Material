package com.cg.ab.dao;

import java.util.ArrayList;

import com.cg.ab.bean.Author;
import com.cg.ab.bean.Book;

public interface AuthorDaoInterface {

	public Author addAuth(Author auth);
	public Book addBook(Book book);
	
	public ArrayList<Author> fetchAllEmp();
	
	public Author getEmpById(int authId);

	
}
