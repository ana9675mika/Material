package com.cg.ab.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.ab.bean.Author;
import com.cg.ab.utill.JPAUtil;


public class AuthorDaoImpl implements AuthorDaoInterface {
	
	EntityManager em=null;
	EntityTransaction entityTran=null;
	public AuthorDaoImpl()
	{
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
	}

	@Override
	public Author addAuth(Author auth) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Author> fetchAllEmp() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author deleteEmp(int authId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author getEmpById(int authId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Author updateEmp(int authId, String name) {
		// TODO Auto-generated method stub
		return null;
	}

}
