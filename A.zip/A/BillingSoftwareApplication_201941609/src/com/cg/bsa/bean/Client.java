package com.cg.bsa.bean;

public class Client {
	private String Name;
	private int productCode;
	private int Quantity;
	
	
	public Client(String name, int productCode, int quantity) {
		super();
		Name = name;
		this.productCode = productCode;
		Quantity = quantity;
	}
	
	

	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public int getQuantity() {
		return Quantity;
	}
	public void setQuantity(int quantity) {
		Quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "Name=" + Name + ", productCode=" + productCode + ", Quantity=" + Quantity ;
	}
	

}
