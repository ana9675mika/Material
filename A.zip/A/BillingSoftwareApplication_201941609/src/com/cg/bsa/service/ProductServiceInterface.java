package com.cg.bsa.service;

import com.cg.bsa.bean.Product;
import com.cg.bsa.exception.ProductException;

public interface ProductServiceInterface  {

	public Product getProductDetails(int productCode) throws ProductException;
	public boolean validateProductCode(int productCode);
	public boolean validateQuantity(int Quantity);
	
}
