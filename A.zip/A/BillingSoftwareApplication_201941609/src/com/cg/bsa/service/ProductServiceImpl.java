package com.cg.bsa.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bsa.bean.Product;
import com.cg.bsa.dao.ProductDaoImpl;
import com.cg.bsa.exception.ProductException;

public class ProductServiceImpl implements ProductServiceInterface{

	ProductDaoImpl dao;
	//This constructor is used to create a link between service and DAO layer
	public ProductServiceImpl() {
		// TODO Auto-generated constructor stub
		dao = new ProductDaoImpl();
	}
	
//	This method is used to get the Product details of the given product code
	@Override
	public Product getProductDetails(int productCode) throws ProductException {
		// TODO Auto-generated method stub
		if(!validateProductCode(productCode))
			throw new ProductException("Invalid ProductCode");
		
		//else if(!validateQuality(Quantity))
		//throw new ProductException("Invalid Quantity");
		
		else
			return dao.getProductDetails(productCode);
	}
	

//	method to validate the product code using pattern class
	@Override
	public boolean validateProductCode(int productCode) {
		// TODO Auto-generated method stub
		Pattern pat = Pattern.compile("[1][0-4]+");
		Matcher mat = pat.matcher(String.valueOf(productCode));
		return mat.matches();
	}
	
//	method to validate the Quantity using pattern class
	@Override
	public boolean validateQuantity(int  Quantity) {
		// TODO Auto-generated method stub
		Pattern pat = Pattern.compile("[1-9]+");
		Matcher mat = pat.matcher(String.valueOf(Quantity));
		return mat.matches();
	}

}
