package com.cg.bsa.dao;

import java.util.ArrayList;

import java.util.Map;
import java.util.Set;

import com.cg.bsa.bean.Product;
import com.cg.bsa.exception.ProductException;

	public class ProductDaoImpl implements ProductDaoInterface {
		
		Map<Integer, Product> products;
		DataContainer collection = new DataContainer();
		
		public ProductDaoImpl() {
			// TODO Auto-generated constructor stub
			products = DataContainer.createCollection();
			products.put(1001, new Product(1001,"iPhone", "Electronics", 35000));
			products.put(1002, new Product(1002,"LEDTV", "Electronics", 45000));
			products.put(1003, new Product(1003,"Teddy", "Toys", 800));
			products.put(1004, new Product(1004,"Telescope", "Toys", 5000));
			
			
		
		}
		
		@Override
		public Product getProductDetails(int productCode) throws ProductException {
			// TODO Auto-generated method stub
			Set<Integer> set = products.keySet();
			Integer key = null;
			for(Integer s : set){
				if(s.equals(productCode)){
					key = s;
				}
			}
			
			
			if(key == null){
				System.err.println("Sorry! The Product Code is not available.");
				//throw new ProductException("Given Product Code Does Not Exist");
			}
			else
				
				
				for (Map.Entry<Integer, Product> i : products.entrySet()) {
					if (i.getKey() == productCode) {

						return products.get(i.getKey());

					}
				}
			throw new ProductException("Product code is not exist in the hashmap");
				
			}
		
}
