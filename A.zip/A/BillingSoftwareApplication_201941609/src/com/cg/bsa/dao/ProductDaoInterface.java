package com.cg.bsa.dao;

import com.cg.bsa.bean.Product;
import com.cg.bsa.exception.ProductException;

public interface ProductDaoInterface {

	public Product getProductDetails(int productCode) throws ProductException;
}
