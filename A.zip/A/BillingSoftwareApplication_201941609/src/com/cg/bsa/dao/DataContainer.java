package com.cg.bsa.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.bsa.bean.Product;


public class DataContainer {
	
	static Map<Integer, Product> map;
	static Map<Integer, Product> createCollection(){
		
		if(map == null)
			map = new HashMap<Integer, Product>();
		
		return map;
	}

}
