package com.cg.bsa.ui;

import java.util.Scanner;

import com.cg.bsa.bean.Product;
import com.cg.bsa.dao.ProductDaoImpl;
import com.cg.bsa.exception.ProductException;
import com.cg.bsa.service.ProductServiceImpl;

public class Main {

	public static void main(String[] args) throws ProductException {
		
		Scanner scanner = new Scanner(System.in);
		ProductDaoImpl pdao=new ProductDaoImpl();
		ProductServiceImpl service = null;
	

		int option = 0;

		do {
//			This is to display the menu
			System.out.println("1. Generate Bill by entering Product Code and Quantity");
			System.out.println("2. Exit");

			option = scanner.nextInt();
			switch (option) {
			case 1:
				//Case1: is to take inputs from the user and to validate the user inputs
				service = new ProductServiceImpl();
				System.out.println("Enter the Product Code: ");
				int productCode = scanner.nextInt();
				if(!service.validateProductCode(productCode))
					throw new ProductException("Please Enter a Valid product code");
	
				System.out.println("Enter the Quantity: ");
				int Quantity = scanner.nextInt();
				if(!service.validateQuantity(Quantity))
					throw new ProductException("Please Enter a Valid Quantity");
			
				Product pcc = service.getProductDetails(productCode);
			
				System.out.println("Product Name:\t" + pcc.getProductName());
				System.out.println("Product Category:\t" + pcc.getProductCategory());
				System.out.println("Product Price(Rs):\t" + pcc.getProductPrice());
				System.out.println("Quantity:\t" + Quantity);
				System.out.println("Line Total:\t" + pcc.getProductPrice() * Quantity);
				

				break;
			default:
			case 2:
				System.out.println("Exited...");
				break;
			}

		} while (option != 2);
		scanner.close();
	}
		
		
}
	
