package com.cg.lab2.dao;

import java.util.ArrayList;
import javax.persistence.*;

import com.cg.lab2.bean.Author;
import com.cg.lab2.bean.Book;
import com.cg.lab2.util.JPAUtil;

public class AuthorDaoImpl implements AuthorDao {
	
	EntityManager em=null;
	EntityTransaction entityTran=null;
	public AuthorDaoImpl()
	{
		em=JPAUtil.getEntityManager();
		entityTran=em.getTransaction();
	}


	@Override
	public Author addAuth(Author author) {
		entityTran.begin();
		em.persist(author);
		entityTran.commit();
		return author;
	}

	@Override
	public Book addBook(Book book) {
		entityTran.begin();
		em.persist(book);
		entityTran.commit();
		return book;
	}

	@Override
	public ArrayList<Book> fetchAllBook() {
		String selAllQuery="SELECT book FROM Book book";
		TypedQuery<Book> tq=em.createQuery(selAllQuery,Book.class);
		ArrayList<Book> bookList=(ArrayList) tq.getResultList();
		return bookList;
	}

	@Override
	public ArrayList<Book> getBookByName(String authorName) {
		String selAllQuery="SELECT book FROM Book book WHERE authorName=(?)";
		TypedQuery<Book> tq=em.createQuery(selAllQuery,Book.class);
		tq.setParameter(1, authorName);
		ArrayList<Book> bookList=(ArrayList)tq.getResultList();
		return bookList;
	}

	@Override
	public ArrayList<Book> allBooks(int minprice,int maxprice) {
		String selAllQuery="SELECT book FROM Book book WHERE price BETWEEN (?) AND (?)";
		TypedQuery<Book> tq=em.createQuery(selAllQuery,Book.class);
		tq.setParameter(1, minprice);
		tq.setParameter(2, maxprice);
		ArrayList<Book> bookList=(ArrayList) tq.getResultList();
		return bookList;
	}

	@Override
	public Author getAuthById(String isbn) {
		Author a2=em.find(Author.class, isbn);
		return a2;
	}


}
