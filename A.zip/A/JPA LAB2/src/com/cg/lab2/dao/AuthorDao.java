package com.cg.lab2.dao;

import java.util.ArrayList;

import com.cg.lab2.bean.Author;
import com.cg.lab2.bean.Book;
public interface AuthorDao {

	public Author addAuth(Author author);
	public Book addBook(Book book);
	
	public ArrayList<Book> fetchAllBook();
	public ArrayList<Book> getBookByName(String authorName);
	public ArrayList<Book> allBooks(int minprice,int maxprice);
	public Author getAuthById(String bookisbn);
}
