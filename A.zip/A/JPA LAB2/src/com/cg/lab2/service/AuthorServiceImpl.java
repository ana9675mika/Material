package com.cg.lab2.service;

import java.util.ArrayList;

import com.cg.lab2.bean.Author;
import com.cg.lab2.bean.Book;
import com.cg.lab2.dao.AuthorDao;
import com.cg.lab2.dao.AuthorDaoImpl;

public class AuthorServiceImpl implements AuthorService{

	AuthorDao authDao;
	public AuthorServiceImpl() {
		
		authDao=new AuthorDaoImpl();
	}

	@Override
	public Author addAuth(Author author) {

		return authDao.addAuth(author);
	}

	@Override
	public Book addBook(Book book) {
		
		return authDao.addBook(book);
	}

	@Override
	public ArrayList<Book> fetchAllBook() {

		return authDao.fetchAllBook();
	}

	@Override
	public ArrayList<Book> getBookByName(String name) {
	
		return authDao.getBookByName(name);
	}

	@Override
	public ArrayList<Book> allBooks(int minprice,int maxprice) {
		
		return authDao.allBooks(minprice, maxprice);
	}

	@Override
	public Author getAuthById(String bookisbn) {
		
		return authDao.getAuthById(bookisbn);
	}

}
