package com.cg.lab2.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
public class Author {
	@Id
	@Column(name="author_Id",length=10)
	private int authorId;
	
	@Column(name="author_Name",length=10)
	private String authorName;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="authbook")
	private Set<Book> empSet=new HashSet<Book>();
	

	public int getAuthorId() {
		return authorId;
	}

	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public Author(int authorId, String authorName) {
		super();
		this.authorId = authorId;
		this.authorName = authorName;
	}

	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "authorId=" + authorId + ", authorName=" + authorName;
	}

	

}
