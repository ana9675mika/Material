package com.cg.lab2.main;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

import com.cg.lab2.bean.Author;
import com.cg.lab2.bean.Book;
import com.cg.lab2.service.AuthorServiceImpl;

public class TestAuthor {
	public static void main(String args[])
	{
		
		AuthorServiceImpl authSer= new AuthorServiceImpl();
		Scanner sc=new Scanner(System.in);
		int option = 0;

		do {

			System.out.println("\n1. Inserting The Data");
			System.out.println("2. Query all Books ");
			System.out.println("3.Query all Books written by given author name");
			System.out.println("4.List all books with given price range. e.g. between Rs. 500 to 1000");
			System.out.println("5.List the author name for given book id. ");
			System.out.println("6.Exit");

			option = sc.nextInt();
			switch (option) {
			case 1:
						System.out.println("Enter author id");
					
					int id=sc.nextInt();
						System.out.println("Enter name");
						String Name=sc.next();
						System.out.println(".........inserting records of Author........");
						Author a= new Author();
						a.setAuthorId(id);
						a.setAuthorName(Name);
						Author a2=authSer.addAuth(a);
						System.out.println(a2 + " is inserted in table\n");
						
						System.out.println("Enter Book isbn");
						String isbn=sc.next();
						System.out.println("Enter Book title");
						String title=sc.next();
						System.out.println("Enter Book price");
						int bookprice=sc.nextInt();
		
						System.out.println(".........inserting records of Book........");
						Book b=new Book();
						b.setIsbn(isbn);
						b.setTitle(title);
						b.setPrice(bookprice);
						Book b2=authSer.addBook(b);
						
						Set<Book> bookSet=new HashSet();
			         	bookSet.add(b);
			      
						System.out.println(b2 + " is inserted in table");
						break;
			case 2:
						System.out.println("......fetch all records.........");
						ArrayList<Book> bList=authSer.fetchAllBook();
						for(Book tempB:bList)
						{
							System.out.println(tempB.getIsbn()+"\t"
									+tempB.getTitle()+"\t"
									+tempB.getPrice()+"\t"
									);
						}
						break;
						
			case 3:
						
					System.out.println("get all Books written by given author name");
					System.out.println("Enter author name to get all his books");
					String authName=sc.next();
					ArrayList<Book> bookList=authSer.getBookByName(authName);
						for(Book tempB:bookList)
						{
							System.out.println(tempB.getIsbn()+"\t"
									+tempB.getTitle()+"\t"
									+tempB.getPrice()+"\t"
									);
						}
						break;
			case 4:
						
					System.out.println("get all Books written by given book price");
					System.out.println("enter book price range to get that book details");
					int minprice=sc.nextInt();
					int maxprice=sc.nextInt();
					ArrayList<Book> book1List=authSer.allBooks(minprice, maxprice);
						for(Book tempB:book1List)
						{
							System.out.println(tempB.getIsbn()+"\t"
									+tempB.getTitle()+"\t"
									+tempB.getPrice()+"\t"
									);
						}
						break;
			case 5:			
						System.out.println(".....fetch only one record........");
						System.out.println("Enter book isbn To fetch the corresponding author");
						String bookisbn=sc.next();
						Author aa=authSer.getAuthById(bookisbn);
						System.out.println(aa);
						break;
			default:
			case 6:
				System.out.println("Exited...");
				break;
			}

		} while (option != 6);
		sc.close();
	
   }
}
