package com.cg.emp.bean;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.*;

public class Client {
	public static void main(String args[])
	{

		Resource res=new ClassPathResource("beans.xml");
		XmlBeanFactory factory=new XmlBeanFactory(res);
		
		{
			Employee emp=(Employee) factory.getBean("e1");///getBean will return the bean whose id is emp
    	System.out.println(emp);
    	
    	Employee emp2=(Employee) factory.getBean("e2");///getBean will return the bean whose id is emp
    	System.out.println(emp2);
//		UserCredentials user=(UserCredentials) factory.getBean("cred");
//		System.out.println(user);
//				
	    }
		System.out.println("in main");
	}

}
