package com.cg.emp.bean;

import java.util.ArrayList;

import org.springframework.beans.factory.InitializingBean;

public class Employee implements InitializingBean {

	private String FirstName;
	private String LastName;
	private int age;
	Department dept;
	
	public Employee(Department d2)
	{
		this.dept=d2;
	}


	public String getFirstName() {
		return FirstName;
	}
	public Department getDept() {
		return dept;
	}
	public void setDept(Department dept) {
		this.dept = dept;
	}
	public void setFirstName(String firstName) {
		FirstName = firstName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Employee(String firstName, String lastName, int age) {
		
		this.FirstName = firstName;
		this.LastName = lastName;
		this.age = age;
	}
	
	public Employee(String name, int age) {
			
			FirstName = name.substring(0, name.indexOf(" "));
			LastName = name.substring(name.indexOf(" ")+1);
			this.age = age;
		}
	
	public Employee() {
		Department dept=new Department();
	}
	@Override
	public String toString() {
		return "FirstName=" + FirstName + ", LastName=" + LastName + ", age=" + age + ", dept=" + dept;
	}
	
	
	public void m1()
	{
		System.out.println("do some initialization work here........");
	}
	
	public void m2()
	{
		System.out.println("clean up of bean..............");
	}


	@Override
	public void afterPropertiesSet() throws Exception {
		System.out.println("allocated source ............");
		
	}
	
}
