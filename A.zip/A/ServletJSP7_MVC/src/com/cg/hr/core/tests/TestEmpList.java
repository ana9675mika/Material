package com.cg.hr.core.tests;

import java.util.ArrayList;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.exceptions.EmpException;
import com.cg.hr.core.service.EmployeeServiceImpl;

public class TestEmpList {

	public static void main(String[] args) {
		try
		{
			EmployeeServiceImpl services=new EmployeeServiceImpl();
		
		ArrayList<Employee> empList=services.fetchAllEmp();
		for(Employee emp: empList)
		{
			System.out.println(emp);
		}
	}
		catch(EmpException e)
		{
			e.printStackTrace();
		}

	}

}
