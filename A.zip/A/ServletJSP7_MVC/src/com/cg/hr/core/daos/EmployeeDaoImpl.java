package com.cg.hr.core.daos;

import java.sql.*;
import java.util.ArrayList;

import javax.persistence.*;

import com.cg.hr.core.beans.Employee;
import com.cg.hr.core.exceptions.EmpException;
import com.cg.hr.core.util.JDBCUtil;
import com.cg.hr.core.util.JPAUtil;

public class EmployeeDaoImpl implements EmployeeDao
{	
	private Connection connect;
	public EmployeeDaoImpl() throws EmpException
	{
		JDBCUtil util=new JDBCUtil();
		connect=util.getConnect();
	}

	/*@Override
	public Employee addEmp(Employee emp) {
		entityTran.begin();
		em.persist(emp);
		entityTran.commit();
		return emp;
	}*/

	@Override
	public ArrayList<Employee> fetchAllEmp() throws EmpException {
		
		Statement stmt=null;
		ResultSet rs=null;
		ArrayList<Employee> empList=new ArrayList<>();
		try {
		
			stmt=connect.createStatement();
			rs=stmt.executeQuery("SELECT EMPNO,ENAME, SAL FROM emp");
			
			while(rs.next())
			{
				int empNo=rs.getInt("EMPNO");
				String empnm=rs.getString("ENAME");
				float empSal=rs.getFloat("SAL");
				
				Employee emp=new Employee(empNo,empnm,empSal);
				empList.add(emp);
				}
			return empList;
	}
		catch(Exception e)
		{
			throw new EmpException("Something WRong",e);
		}
		finally {
			try {
				if(rs!=null)
				{
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
			} catch (SQLException e) {
				throw new EmpException("something Wrong",e);
			}
		}
	}

	@Override
	protected void finalize() throws Throwable {
		if(connect!=null)
		{
			connect.close();
		}
		super.finalize();
	}
/*
	@Override
	public Employee deleteEmp(int empId) {
		Employee e1=em.find(Employee.class, empId);
		entityTran.begin();
		em.remove(e1);
		entityTran.commit();
		return e1;
	}
*/
	@Override
	public Employee getEmpById(int empId) throws EmpException {
		
		PreparedStatement stmt=null;
		ResultSet rs=null;
		Employee emp=null;
		try {
		
			stmt=connect.prepareStatement("SELECT EMPNO,ENAME, SAL FROM emp WHERE EMPNO=?");
			stmt.setInt(1, empId);
			rs=stmt.executeQuery();
			
			while(rs.next())
			{
				int empNo=rs.getInt("EMPNO");
				String empnm=rs.getString("ENAME");
				float empSal=rs.getFloat("SAL");
				
				emp=new Employee(empNo,empnm,empSal);
				}
			return emp;
	}
		catch(Exception e)
		{
			throw new EmpException("Something WRong",e);
		}
		finally {
			try {
				if(rs!=null)
				{
					rs.close();
				}
				if(stmt!=null)
				{
					stmt.close();
				}
			} catch (SQLException e) {
				throw new EmpException("something Wrong",e);
			}
		}
	}
	}
/*
	@Override
	public Employee updateEmp(int empId, String newName, float newSal) {
		Employee ee=em.find(Employee.class, empId);
		ee.setEmpName(newName);
		ee.setEmpSal(newSal);
		entityTran.begin();
		em.merge(ee);
		entityTran.commit();
		return ee;
	}*/
	


