package com.cg.hr.core.beans;

import javax.persistence.*;

@Entity
@Table(name="emp")

public class Employee
{
	@Id
	//@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="EMPNO",length=20)
	private int empId;
	
	@Column(name="ENAME",length=30)
	private String empName;
	
	@Column(name="SAL",length=10)
	private float empSal;
	
	
	public int getEmpId() {    // empId-------property name::get nikal do nd uska baad phla word small krdo
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {  //empName
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public float getEmpSal() {   //emSal
		return empSal;
	}
	public void setEmpSal(float empSal) {
		this.empSal = empSal;
	}
	
	public Employee() {
		super();
		
	}

	public Employee(int empId, String empName, float empSal) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSal = empSal;
		
	}
	@Override
	public String toString() {
		return "empId=" + empId + ", empName=" + empName + ", empSal=" + empSal;
	}
	

}
